module.exports = {
  env:0, // 1生成环境, 0开发环境
  url: 'http://gczj.sinmore.vip',
  // 获取验证码的倒计时长
  countNum: 60,
  jpush_id: 'a1', // TODOS
  // 加载更多的时候, 每次的加载数量
  pageSize: 5
}
