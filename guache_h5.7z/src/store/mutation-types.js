export const SET_Mobile_Height = 'SET_Mobile_Height'
export const SET_TOKEN = 'SET_TOKEN'
export const SET_TAB = 'SET_TAB'
export const SET_LOADING = 'SET_LOADING'

export const SHOPCAR_ADD = 'SHOPCAR_ADD'
export const SHOPCAR_SELECTED_PRODUCT = 'SHOPCAR_SELECTED_PRODUCT'
export const SHOPCAR_SET_BUYNUM = 'SHOPCAR_SET_BUYNUM'
export const SET_JPUSH_ID = 'SET_JPUSH_ID'

// export const SHOPCAR_EDIT_SELECTED_PRODUCT = 'SHOPCAR_EDIT_SELECTED_PRODUCT'
