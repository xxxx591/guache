import * as types from './types'

const state = {
  shopCarList: []
}

export default state
